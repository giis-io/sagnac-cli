# Bibliothèque des contrôles écrits en sh POSIX (macOS, Linux, WSL2).
# shellcheck disable=SC2034  # SAGNAC_RC et SAGNAC_DRAW sont lus par les contrôles qui sourcent ce fichier
# Chaque contrôle commence par :   . "$SAGNAC_LIB"
#
# Contrat (labs/_cadre/CONTRAT.md) : le contrôle se termine par une seule de ces fonctions.
#   sagnac_reussite [OBSERVE [ATTENDU]]          code de sortie 0
#   sagnac_echec CODE [OBSERVE [ATTENDU]]        code de sortie 1, faute de l'élève
#   sagnac_plateforme CODE [OBSERVE [ATTENDU]]   code de sortie 2, précondition de plateforme absente
# OBSERVE et ATTENDU sont des valeurs typées (booléen, entier, valeur d'une liste fermée),
# jamais un texte lu sur le poste de l'élève : l'exécuteur refuse tout le reste.

_sagnac_ecrire() {
    if [ -n "$2" ]; then printf 'observed=%s\n' "$2" >>"$SAGNAC_RESULT"; fi
    if [ -n "$3" ]; then printf 'expected=%s\n' "$3" >>"$SAGNAC_RESULT"; fi
    if [ -n "$1" ]; then printf 'code=%s\n' "$1" >>"$SAGNAC_RESULT"; fi
}

sagnac_reussite() { _sagnac_ecrire "" "$1" "$2"; exit 0; }
sagnac_echec() { _sagnac_ecrire "$1" "$2" "$3"; exit 1; }
sagnac_plateforme() { _sagnac_ecrire "$1" "$2" "$3"; exit 2; }

# sagnac_executer DELAI_S FICHIER_SORTIE FICHIER_ERREUR COMMANDE [ARGS...]
# Lance la commande de l'élève avec une entrée vide, un délai borné et sans les
# variables SAGNAC_* (graine et fichier de résultat restent hors de sa portée).
# Positionne SAGNAC_RC : code de sortie de la commande, ou -1 si le délai est dépassé.
sagnac_executer() {
    _delai=$1 _sortie=$2 _erreur=$3
    shift 3
    rm -f "$_sortie.delai"
    (
        unset SAGNAC_RESULT SAGNAC_SEED SAGNAC_LIB SAGNAC_CHECK SAGNAC_LAB SAGNAC_WORKSPACE SAGNAC_CLUSTER
        exec "$@"
    ) >"$_sortie" 2>"$_erreur" </dev/null &
    _pid=$!
    (
        sleep "$_delai"
        if kill -0 "$_pid" 2>/dev/null; then
            : >"$_sortie.delai"
            kill -9 "$_pid" 2>/dev/null
        fi
    ) >/dev/null 2>&1 </dev/null &
    _veille=$!
    wait "$_pid"
    SAGNAC_RC=$?
    kill "$_veille" 2>/dev/null
    wait "$_veille" 2>/dev/null
    if [ -e "$_sortie.delai" ]; then
        SAGNAC_RC=-1
        rm -f "$_sortie.delai"
    fi
}

# sagnac_tirer N : entier pseudo-aléatoire dans [0, N) tiré de la graine du passage.
# Arithmétique entière du shell : même tirage sur toutes les plateformes pour une même graine.
_sagnac_etat=""
sagnac_tirer() {
    if [ -z "$_sagnac_etat" ]; then _sagnac_etat=$(( ${SAGNAC_SEED:-0} % 2147483647 + 1 )); fi
    _sagnac_etat=$(( (_sagnac_etat * 48271) % 2147483647 ))
    SAGNAC_DRAW=$(( _sagnac_etat % $1 ))
}

# --- Cluster du lab (meta.yaml : cluster: <nom> ; CONTRAT.md, section 7 ter) -----------------------
# kubectl épinglé (versions.yaml, vérifié par sagnac-tools) et kubeconfig de l'identité « contrôle » du
# cache Sagnac : compte sagnac-controle, limité à l'espace sagnac-check (Pod Security « restricted »,
# aucune sortie réseau des pods). Jamais l'administrateur, jamais ~/.kube/config. L'API est sur 127.0.0.1 :
# sous Linux, l'exécuteur la rend joignable dans l'espace de noms réseau de check par un relais limité à ce
# seul port. Aucun appel au moteur de conteneurs.

# sagnac_kubectl ARGS... : kubectl sur le cluster du lab, identité contrôle, délai de requête borné.
sagnac_kubectl() {
    _sagnac_k="$HOME/.cache/sagnac/clusters/${SAGNAC_CLUSTER:?SAGNAC_CLUSTER absent : le lab ne déclare pas de cluster}"
    "$_sagnac_k/kubectl" --kubeconfig "$_sagnac_k/kubeconfig" --request-timeout=20s "$@"
}

# sagnac_cluster_requis [CODE] : précondition de plateforme (code 2, CLUSTER_MISSING par défaut)
# si l'API du cluster ne répond pas à l'identité contrôle.
sagnac_cluster_requis() {
    sagnac_kubectl auth can-i create pods -n sagnac-check >/dev/null 2>&1 || sagnac_plateforme "${1:-CLUSTER_MISSING}"
}

# sagnac_k8s_espace : SAGNAC_NS, le seul espace où le passage agit (sagnac-check, posé par make setup avec
# PSA « restricted » et une NetworkPolicy sans sortie ; vidé par l'exécuteur avant et après le passage).
# sagnac_k8s_creer_espace : nom gardé pour les contrôles écrits avant le 2026-10-21 ; ne crée rien.
sagnac_k8s_espace() { SAGNAC_NS="sagnac-check"; }
sagnac_k8s_creer_espace() { sagnac_k8s_espace; }

# Sortes d'objets qu'un manifeste de l'élève peut porter (sortie de `kubectl apply -o name`). Un lab peut
# en retirer en posant SAGNAC_K8S_SORTES avant l'appel, jamais en ajouter une que le rôle refuse.
SAGNAC_K8S_SORTES_DEFAUT="pod service configmap secret persistentvolumeclaim deployment.apps statefulset.apps job.batch"

# sagnac_k8s_appliquer FICHIER_OU_DOSSIER : applique les manifestes de l'élève dans SAGNAC_NS.
# 1. Essai à blanc côté serveur (--dry-run=server -o name), avec l'identité contrôle : un objet à portée
#    cluster ou hors du rôle est refusé par le serveur ; un pod qui viole PSA « restricted » aussi (et un
#    gabarit de déploiement qui la violerait, par l'avertissement du serveur) ; un `namespace:` autre que
#    l'espace du passage aussi.
# 2. Chaque objet est d'une sorte de la liste blanche.
# 3. Seulement alors, application réelle.
# Rend 0, ou 1 avec SAGNAC_K8S_REFUS : rejected (manifeste invalide ou autre espace), forbidden_kind (sorte
# hors liste ou refusée par le rôle), pod_security (PSA).
sagnac_k8s_appliquer() {
    sagnac_k8s_espace
    SAGNAC_K8S_REFUS=""
    _sagnac_err="${TMPDIR:-/tmp}/sagnac-k8s-appliquer.$$"
    _sagnac_noms=$(sagnac_kubectl -n "$SAGNAC_NS" apply --dry-run=server -o name -R -f "$1" 2>"$_sagnac_err")
    _sagnac_rc=$?
    if grep -q "violate.* PodSecurity\|violates PodSecurity" "$_sagnac_err"; then
        SAGNAC_K8S_REFUS=pod_security
    elif [ $_sagnac_rc -ne 0 ] && grep -qi "forbidden" "$_sagnac_err"; then
        SAGNAC_K8S_REFUS=forbidden_kind
    elif [ $_sagnac_rc -ne 0 ] || [ -z "$_sagnac_noms" ]; then
        SAGNAC_K8S_REFUS=rejected
    fi
    rm -f "$_sagnac_err"
    [ -z "$SAGNAC_K8S_REFUS" ] || return 1
    for _sagnac_o in $_sagnac_noms; do
        case " ${SAGNAC_K8S_SORTES:-$SAGNAC_K8S_SORTES_DEFAUT} " in
            *" ${_sagnac_o%%/*} "*) ;;
            *) SAGNAC_K8S_REFUS=forbidden_kind; return 1 ;;
        esac
    done
    sagnac_kubectl -n "$SAGNAC_NS" apply -R -f "$1" >/dev/null 2>&1 || { SAGNAC_K8S_REFUS=rejected; return 1; }
}
