# Bibliothèque des contrôles écrits en sh POSIX (macOS, Linux, WSL2).
# shellcheck disable=SC2034  # SAGNAC_RC et SAGNAC_DRAW sont lus par les contrôles qui sourcent ce fichier
# Chaque contrôle commence par :   . "$SAGNAC_LIB"
#
# Contrat (labs/_cadre/CONTRAT.md) : le contrôle se termine par une seule de ces fonctions.
#   sagnac_reussite [OBSERVE [ATTENDU]]          code de sortie 0
#   sagnac_echec CODE [OBSERVE [ATTENDU]]        code de sortie 1, faute de l'élève
#   sagnac_plateforme CODE [OBSERVE [ATTENDU]]   code de sortie 2, précondition de plateforme absente
# OBSERVE et ATTENDU sont des valeurs typées (booléen, entier, valeur d'une liste fermée),
# jamais un texte lu sur le poste de l'élève : l'exécuteur refuse tout le reste.

_sagnac_ecrire() {
    if [ -n "$2" ]; then printf 'observed=%s\n' "$2" >>"$SAGNAC_RESULT"; fi
    if [ -n "$3" ]; then printf 'expected=%s\n' "$3" >>"$SAGNAC_RESULT"; fi
    if [ -n "$1" ]; then printf 'code=%s\n' "$1" >>"$SAGNAC_RESULT"; fi
}

sagnac_reussite() { _sagnac_ecrire "" "$1" "$2"; exit 0; }
sagnac_echec() { _sagnac_ecrire "$1" "$2" "$3"; exit 1; }
sagnac_plateforme() { _sagnac_ecrire "$1" "$2" "$3"; exit 2; }

# sagnac_executer DELAI_S FICHIER_SORTIE FICHIER_ERREUR COMMANDE [ARGS...]
# Lance la commande de l'élève avec une entrée vide, un délai borné et sans les
# variables SAGNAC_* (graine et fichier de résultat restent hors de sa portée).
# Positionne SAGNAC_RC : code de sortie de la commande, ou -1 si le délai est dépassé.
sagnac_executer() {
    _delai=$1 _sortie=$2 _erreur=$3
    shift 3
    rm -f "$_sortie.delai"
    (
        unset SAGNAC_RESULT SAGNAC_SEED SAGNAC_LIB SAGNAC_CHECK SAGNAC_LAB SAGNAC_WORKSPACE
        exec "$@"
    ) >"$_sortie" 2>"$_erreur" </dev/null &
    _pid=$!
    (
        sleep "$_delai"
        if kill -0 "$_pid" 2>/dev/null; then
            : >"$_sortie.delai"
            kill -9 "$_pid" 2>/dev/null
        fi
    ) >/dev/null 2>&1 </dev/null &
    _veille=$!
    wait "$_pid"
    SAGNAC_RC=$?
    kill "$_veille" 2>/dev/null
    wait "$_veille" 2>/dev/null
    if [ -e "$_sortie.delai" ]; then
        SAGNAC_RC=-1
        rm -f "$_sortie.delai"
    fi
}

# sagnac_tirer N : entier pseudo-aléatoire dans [0, N) tiré de la graine du passage.
# Arithmétique entière du shell : même tirage sur toutes les plateformes pour une même graine.
_sagnac_etat=""
sagnac_tirer() {
    if [ -z "$_sagnac_etat" ]; then _sagnac_etat=$(( ${SAGNAC_SEED:-0} % 2147483647 + 1 )); fi
    _sagnac_etat=$(( (_sagnac_etat * 48271) % 2147483647 ))
    SAGNAC_DRAW=$(( _sagnac_etat % $1 ))
}
