#!/bin/sh
# Ramassage de l'espace sagnac-check du cluster du lab (CONTRAT.md, section 4), avec l'identité contrôle
# (jamais l'administrateur). Lancé par l'exécuteur avant le premier contrôle et après le dernier, même après
# un délai dépassé, un plafond atteint ou une interruption, avec l'environnement et l'enveloppe réseau des
# contrôles. Supprime toutes les sortes d'objets que le rôle permet de créer (pods sans délai de grâce),
# puis attend leur disparition et celle des volumes de leurs PVC (90 s au plus).
# Codes : 0 espace vide, ou cluster injoignable (les contrôles rendront CLUSTER_MISSING) ;
# 1 objets restants : l'exécuteur rend CLUSTER_DIRTY (code 2) à l'ouverture.
# shellcheck source=labs/_cadre/lib/controle.sh
. "$SAGNAC_LIB"
sagnac_k8s_espace
SORTES="deployments.apps,statefulsets.apps,replicasets.apps,jobs.batch,pods,services,configmaps,secrets,persistentvolumeclaims"

restes() {
    sagnac_kubectl -n "$SAGNAC_NS" get "$SORTES" -o name 2>/dev/null | grep -v '^configmap/kube-root-ca.crt$'
    sagnac_kubectl get persistentvolumes \
        -o jsonpath='{range .items[?(@.spec.claimRef.namespace=="sagnac-check")]}{.metadata.name}{"\n"}{end}' 2>/dev/null
}

# Finaliseurs posés par l'élève (le rôle a `patch`) : retirés, sinon l'objet bloque sa suppression et le
# passage suivant rendrait CLUSTER_DIRTY.
sans_finaliseurs() {
    for o in $(sagnac_kubectl -n "$SAGNAC_NS" get "$SORTES" \
            -o jsonpath='{range .items[?(@.metadata.finalizers)]}{.kind}/{.metadata.name}{" "}{end}' 2>/dev/null); do
        sagnac_kubectl -n "$SAGNAC_NS" patch "$o" --type=merge -p '{"metadata":{"finalizers":null}}' >/dev/null 2>&1
    done
}

sagnac_kubectl get --raw /readyz >/dev/null 2>&1 || exit 0
[ -n "$(restes)" ] || exit 0
sans_finaliseurs
sagnac_kubectl -n "$SAGNAC_NS" delete pods --all --grace-period=0 --force --wait=false >/dev/null 2>&1
sagnac_kubectl -n "$SAGNAC_NS" delete "$SORTES" --all --wait=false >/dev/null 2>&1
n=0
while [ $n -lt 90 ]; do
    [ -n "$(restes)" ] || exit 0
    sans_finaliseurs
    sleep 1
    n=$((n + 1))
done
exit 1
