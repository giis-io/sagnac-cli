# Cibles communes du kit élève (contrat : labs/_cadre/CONTRAT.md, section « Cibles make »).
# Le Makefile du lab définit LAB_DIR et CADRE_DIR puis inclut ce fichier ; il n'écrit rien d'autre.
# La solution n'est jamais appelée d'ici : `solve` vit dans solution/Makefile, hors du kit élève.
#   make tools   télécharge dans le cache Sagnac les outils de meta.yaml (labs/versions.yaml) et vérifie
#                leur somme SHA-256 ; seule cible qui peut demander le réseau, idempotente
#   make setup   vérifie les outils (make tools), crée ou démarre le cluster si meta.yaml en déclare un
#                (bin/sagnac-cluster), puis crée l'espace workspace/ depuis starter/ (lib/espace.sh : copie
#                dans un dossier temporaire puis renommage, un setup interrompu se relance tel quel) ; ne
#                touche pas à un espace existant et signale celui à qui il manque des éléments de starter/.
#                SAGNAC_OFFLINE=1 : vérification sans téléchargement
#   make cluster-delete  supprime le cluster du lab (partagé avec les autres labs qui le déclarent)
#   make check   vérifie l'espace ; préférez sagnac check, qui rend le code de l'oracle tel quel.
#                Dans le kit (sans _cadre/sagnac_local.py), délègue à la CLI installée : sagnac check <lab>
#   make clean   supprime l'espace (idempotent)
#   make oracle  rejoue rouge → vert → mutants et écrit checks/RESULTAT.md (dépôt de fabrication)
# Toute commande citée ici ou dans lab.md est la CLI sagnac, une cible de ce fichier ou un fichier du kit
# (labs/_cadre/tests/test_kit.py, test_commandes_citees).
CADRE_DIR ?= $(abspath $(LAB_DIR)/../_cadre)
WORKSPACE ?= $(LAB_DIR)/workspace
PYTHON ?= python3
SAGNAC ?= sagnac
LAB_ID := $(notdir $(LAB_DIR))
VERSIONS ?= $(abspath $(CADRE_DIR)/../versions.yaml)

.PHONY: tools setup check clean oracle cluster-delete

tools:
	@sh "$(CADRE_DIR)/bin/sagnac-tools" install "$(LAB_DIR)/meta.yaml" "$(VERSIONS)"

setup: tools
	@if grep -q '^cluster:' "$(LAB_DIR)/meta.yaml"; then \
		if [ -f "$(VERSIONS)" ]; then sh "$(CADRE_DIR)/bin/sagnac-cluster" ensure "$(LAB_DIR)/meta.yaml" "$(VERSIONS)"; \
		else sh "$(CADRE_DIR)/bin/sagnac-cluster" ensure "$(LAB_DIR)/meta.yaml" --manifest "$(LAB_DIR)/.sagnac/tools.manifest"; fi \
		|| exit $$?; \
	fi
	@sh "$(CADRE_DIR)/lib/espace.sh" "$(LAB_DIR)/starter" "$(WORKSPACE)" "$(LAB_ID)"

# make rend toujours 2 quand une commande échoue : on l'explique au lieu de laisser croire à une panne.
# Dépôt de fabrication : l'exécuteur local. Kit élève (sagnac_local.py n'y est pas) : la CLI installée.
check:
	@if [ -f "$(CADRE_DIR)/sagnac_local.py" ]; then \
		$(PYTHON) "$(CADRE_DIR)/sagnac_local.py" check "$(LAB_DIR)" --workspace "$(WORKSPACE)"; code=$$?; \
	elif command -v "$(SAGNAC)" >/dev/null 2>&1; then \
		cd "$(LAB_DIR)" && "$(SAGNAC)" check "$(LAB_ID)"; code=$$?; \
	else \
		echo "La vérification passe par la CLI sagnac, introuvable sur ce poste (commande absente du PATH). Installez-la, puis lancez depuis workspace/ : sagnac check $(LAB_ID)" >&2; \
		exit 64; \
	fi; \
	if [ $$code -ne 0 ]; then \
		echo "(make va afficher « Error » et rendre 2 : le code de la vérification est $$code, celui de la ligne Résultat ; sagnac check le rend tel quel)"; \
	fi; exit $$code

clean:
	@rm -rf "$(WORKSPACE)"

cluster-delete:
	@if grep -q '^cluster:' "$(LAB_DIR)/meta.yaml"; then sh "$(CADRE_DIR)/bin/sagnac-cluster" delete "$(LAB_DIR)/meta.yaml"; fi

oracle:
	@if [ ! -f "$(CADRE_DIR)/harnais.py" ]; then \
		echo "make oracle sert au dépôt de fabrication des labs ; pour vérifier votre travail : sagnac check $(LAB_ID)" >&2; \
		exit 64; \
	fi; \
	$(PYTHON) "$(CADRE_DIR)/harnais.py" "$(LAB_DIR)"
