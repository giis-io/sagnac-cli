#!/bin/sh
# verify_executable (étape 1) : hello.sh existe et se lance directement.
# shellcheck source=SCRIPTDIR/../../_cadre/lib/controle.sh
. "$SAGNAC_LIB"
if [ ! -f hello.sh ]; then sagnac_echec HELLO_MISSING missing executable; fi
if [ ! -x hello.sh ]; then sagnac_echec HELLO_NOT_EXECUTABLE not_executable executable; fi
sagnac_reussite executable executable
