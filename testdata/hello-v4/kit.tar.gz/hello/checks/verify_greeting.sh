#!/bin/sh
# verify_greeting (étape 2) : avec un prénom, la commande écrit « Bonjour <prénom> »
# sur la sortie standard et se termine avec le code 0.
# Deux prénoms tirés de la graine à chaque passage, jamais ceux des exemples de l'énoncé :
# une sortie codée en dur ne passe pas. Aucune valeur attendue n'est écrite en clair ici.
# shellcheck source=SCRIPTDIR/../../_cadre/lib/controle.sh
. "$SAGNAC_LIB"
set -- "Maëlle" "Jean-Baptiste" "Aïssatou" "Côme" "Inès" "Noé" "Yasmine" "Thibault" \
       "Fatou" "Gaëtan" "Lucie" "Mamadou" "Hélène" "Bastien" "Chloé" "Ousmane"
sagnac_tirer $#
i1=$((SAGNAC_DRAW + 1))
sagnac_tirer $(($# - 1))
i2=$((SAGNAC_DRAW + 1))
if [ "$i2" -ge "$i1" ]; then i2=$((i2 + 1)); fi
eval "p1=\${$i1}; p2=\${$i2}"

# shellcheck disable=SC2154  # p1 et p2 sont posés par eval
for prenom in "$p1" "$p2"; do
    sagnac_executer 5 "$TMPDIR/sortie" "$TMPDIR/erreur" ./hello.sh "$prenom"
    if [ "$SAGNAC_RC" -eq -1 ]; then sagnac_echec HELLO_GREETING_TIMEOUT timeout compliant; fi
    if [ ! -s "$TMPDIR/sortie" ]; then sagnac_echec HELLO_GREETING_MISSING empty compliant; fi
    if [ "$(cat "$TMPDIR/sortie")" != "Bonjour $prenom" ]; then
        sagnac_echec HELLO_GREETING_UNEXPECTED other_text compliant
    fi
    if [ "$SAGNAC_RC" -ne 0 ]; then sagnac_echec HELLO_GREETING_NONZERO_EXIT nonzero_exit compliant; fi
done
sagnac_reussite compliant compliant
