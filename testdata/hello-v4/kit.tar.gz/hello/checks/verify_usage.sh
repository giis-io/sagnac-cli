#!/bin/sh
# verify_usage (étape 3) : sans argument, rien sur la sortie standard, un message sur la
# sortie d'erreur, code de sortie 64 (EX_USAGE).
# shellcheck source=SCRIPTDIR/../../_cadre/lib/controle.sh
. "$SAGNAC_LIB"
sagnac_executer 5 "$TMPDIR/sortie" "$TMPDIR/erreur" ./hello.sh
if [ "$SAGNAC_RC" -eq -1 ]; then sagnac_echec HELLO_USAGE_TIMEOUT -1 64; fi
# Les deux défauts les plus fréquents sont signalés ensemble, pour éviter deux allers-retours.
if [ "$SAGNAC_RC" -ne 64 ] && [ -s "$TMPDIR/sortie" ]; then
    sagnac_echec HELLO_USAGE_EXIT_CODE_AND_STDOUT "$SAGNAC_RC" 64
fi
if [ "$SAGNAC_RC" -ne 64 ]; then sagnac_echec HELLO_USAGE_EXIT_CODE "$SAGNAC_RC" 64; fi
if [ -s "$TMPDIR/sortie" ]; then sagnac_echec HELLO_USAGE_ON_STDOUT "$SAGNAC_RC" 64; fi
if [ ! -s "$TMPDIR/erreur" ]; then sagnac_echec HELLO_USAGE_MISSING "$SAGNAC_RC" 64; fi
sagnac_reussite "$SAGNAC_RC" 64
