#!/bin/sh
# Ramassage de l'espace sagnac-check du cluster du lab (CONTRAT.md, section 4), avec l'identité contrôle
# (jamais l'administrateur). Lancé par l'exécuteur avant le premier contrôle et après le dernier, même après
# un délai dépassé, un plafond atteint ou une interruption, avec l'environnement et l'enveloppe réseau des
# contrôles. Supprime toutes les sortes d'objets que le rôle permet de créer (pods sans délai de grâce),
# puis attend leur disparition et celle des volumes de leurs PVC (90 s au plus). Applications Argo CD (C10) en
# premier, finaliseurs retirés : tant qu'une application vit, son auto-réparation recréerait ce qu'on supprime ;
# sans finaliseur, sa suppression ne touche pas aux objets qu'elle gérait, supprimés ensuite comme les autres.
# Codes : 0 espace vide, ou cluster injoignable (les contrôles rendront CLUSTER_MISSING) ;
# 1 objets restants : l'exécuteur rend CLUSTER_DIRTY (code 2) à l'ouverture.
# shellcheck source=labs/_cadre/lib/controle.sh
. "$SAGNAC_LIB"
sagnac_k8s_espace
SORTES="deployments.apps,statefulsets.apps,replicasets.apps,jobs.batch,pods,services,configmaps,secrets,persistentvolumeclaims"

# Sorte absente du cluster (Argo CD non installé) : get échoue sans rien écrire, rien à ramasser.
APPS=applications.argoproj.io
applications() { sagnac_kubectl -n "$SAGNAC_NS" get "$APPS" -o name 2>/dev/null; }

restes() {
    applications
    sagnac_kubectl -n "$SAGNAC_NS" get "$SORTES" -o name 2>/dev/null | grep -v '^configmap/kube-root-ca.crt$'
    sagnac_kubectl get persistentvolumes \
        -o jsonpath='{range .items[?(@.spec.claimRef.namespace=="sagnac-check")]}{.metadata.name}{"\n"}{end}' 2>/dev/null
}

# Finaliseurs posés par l'élève (le rôle a `patch`) : retirés, sinon l'objet bloque sa suppression et le
# passage suivant rendrait CLUSTER_DIRTY.
sans_finaliseurs() {
    for o in $(sagnac_kubectl -n "$SAGNAC_NS" get "$SORTES" \
            -o jsonpath='{range .items[?(@.metadata.finalizers)]}{.kind}/{.metadata.name}{" "}{end}' 2>/dev/null); do
        sagnac_kubectl -n "$SAGNAC_NS" patch "$o" --type=merge -p '{"metadata":{"finalizers":null}}' >/dev/null 2>&1
    done
}

sagnac_kubectl get --raw /readyz >/dev/null 2>&1 || exit 0

# --- contrat v3 (ADR-007, CONTRAT.md § 7 quater) : dans cet ordre, (1) politiques Kyverno (B5), VAP d'origine
# élève et leurs liaisons,
# RuntimeClass d'origine élève ; (2) sortes de la liste blanche dans les espaces élèves, hors objets du socle,
# compte « default » et ConfigMap kube-root-ca.crt, puis étiquettes Pod Security des espaces élèves (l'état de
# l'élève est réappliqué par chaque passage) ; (3) objets du passage dans sagnac-oracle. Codes inchangés.
sagnac_k8s_contrat
if [ "$SAGNAC_CONTRAT" = 3 ]; then
    CLUSTER_V3="validatingadmissionpolicybindings.admissionregistration.k8s.io,validatingadmissionpolicies.admissionregistration.k8s.io,runtimeclasses.node.k8s.io"
    # cronjobs.batch en tête : supprimé d'abord, il ne relance plus de Job pendant le ramassage (C2, B5).
    SORTES_V3="cronjobs.batch,$SORTES,networkpolicies.networking.k8s.io,roles.rbac.authorization.k8s.io,rolebindings.rbac.authorization.k8s.io,serviceaccounts"
    # Politiques Kyverno de l'élève (C1, B5) : à part, la sorte n'existe que sur un cluster où Kyverno est posé (une
    # liste de sortes avec une sorte inconnue ferait échouer tout le get).
    KYVERNO_VP=validatingpolicies.policies.kyverno.io
    HORS_SOCLE='sagnac.fr/socle!=true'
    # C3 (B4) : applications et ensembles d'Argo CD des espaces élèves, à part (la sorte n'existe que sur un
    # cluster où Argo CD est posé : une sorte inconnue ferait échouer tout le get), supprimés en premier et sans
    # finaliseur, comme en v2 (C10) : sinon l'auto-réparation recréerait ce que le ramassage supprime.
    ARGO_V3=applicationsets.argoproj.io,applications.argoproj.io
    argo_v3() {
        for ns in $SAGNAC_ESPACES; do
            for o in $(sagnac_kubectl -n "$ns" get "$ARGO_V3" -o name 2>/dev/null); do
                sagnac_kubectl -n "$ns" patch "$o" --type=merge -p '{"metadata":{"finalizers":null}}' >/dev/null 2>&1
                sagnac_kubectl -n "$ns" delete "$o" --wait=false >/dev/null 2>&1
                printf '%s/%s\n' "$ns" "$o"
            done
        done
    }
    restes_v3() {
        sagnac_kubectl get "$KYVERNO_VP" -l sagnac.fr/origine=eleve -o name 2>/dev/null
        for ns in $SAGNAC_ESPACES; do
            sagnac_kubectl -n "$ns" get "$ARGO_V3" -o name 2>/dev/null | sed "s#^#$ns/#"
        done
        sagnac_kubectl get "$CLUSTER_V3" -l sagnac.fr/origine=eleve -o name 2>/dev/null
        for ns in $SAGNAC_ESPACES sagnac-oracle; do
            sagnac_kubectl -n "$ns" get "$SORTES_V3" -l "$HORS_SOCLE" -o name 2>/dev/null \
                | grep -v -e '^configmap/kube-root-ca.crt$' -e '^serviceaccount/default$' | sed "s#^#$ns/#"
        done
    }
    sans_finaliseurs_v3() {
        for ns in $SAGNAC_ESPACES sagnac-oracle; do
            for o in $(sagnac_kubectl -n "$ns" get "$SORTES_V3" -l "$HORS_SOCLE" \
                    -o jsonpath='{range .items[?(@.metadata.finalizers)]}{.kind}/{.metadata.name}{" "}{end}' 2>/dev/null); do
                sagnac_kubectl -n "$ns" patch "$o" --type=merge -p '{"metadata":{"finalizers":null}}' >/dev/null 2>&1
            done
        done
    }
    sagnac_kubectl delete "$KYVERNO_VP" -l sagnac.fr/origine=eleve --wait=false >/dev/null 2>&1
    argo_v3 >/dev/null
    sagnac_kubectl delete "$CLUSTER_V3" -l sagnac.fr/origine=eleve --wait=false >/dev/null 2>&1
    sans_finaliseurs_v3
    for ns in $SAGNAC_ESPACES sagnac-oracle; do
        sagnac_kubectl -n "$ns" delete pods -l "$HORS_SOCLE" --grace-period=0 --force --wait=false >/dev/null 2>&1
        sagnac_kubectl -n "$ns" delete "$SORTES_V3" -l "$HORS_SOCLE" --wait=false \
            --field-selector 'metadata.name!=kube-root-ca.crt,metadata.name!=default' >/dev/null 2>&1
    done
    for ns in $SAGNAC_ESPACES; do
        psa=$(sagnac_kubectl get namespace "$ns" -o jsonpath='{.metadata.labels}' 2>/dev/null \
            | tr ',' '\n' | tr -d '{}' | sed -n 's/^"\(pod-security\.kubernetes\.io\/[^"]*\)".*/\1-/p')
        # shellcheck disable=SC2086  # liste d'étiquettes à retirer
        [ -z "$psa" ] || sagnac_kubectl label namespace "$ns" $psa >/dev/null 2>&1
    done
    n=0
    while [ $n -lt 90 ]; do
        [ -n "$(restes_v3)" ] || exit 0
        argo_v3 >/dev/null
        sans_finaliseurs_v3
        sleep 1
        n=$((n + 1))
    done
    exit 1
fi
[ -n "$(restes)" ] || exit 0
if [ -n "$(applications)" ]; then
    n=0
    while [ -n "$(applications)" ] && [ $n -lt 30 ]; do
        for o in $(applications); do
            sagnac_kubectl -n "$SAGNAC_NS" patch "$o" --type=merge -p '{"metadata":{"finalizers":null}}' >/dev/null 2>&1
        done
        sagnac_kubectl -n "$SAGNAC_NS" delete "$APPS" --all --wait=false >/dev/null 2>&1
        sleep 1
        n=$((n + 1))
    done
fi
sans_finaliseurs
sagnac_kubectl -n "$SAGNAC_NS" delete pods --all --grace-period=0 --force --wait=false >/dev/null 2>&1
sagnac_kubectl -n "$SAGNAC_NS" delete "$SORTES" --all --wait=false >/dev/null 2>&1
n=0
while [ $n -lt 90 ]; do
    [ -n "$(restes)" ] || exit 0
    sans_finaliseurs
    sleep 1
    n=$((n + 1))
done
exit 1
