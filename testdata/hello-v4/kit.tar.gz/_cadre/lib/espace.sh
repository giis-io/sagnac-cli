#!/bin/sh
# Création de l'espace de travail de l'élève depuis starter/ (make setup ; CONTRAT.md, section 7).
#   sh espace.sh STARTER WORKSPACE LAB_ID
# Copie dans un dossier temporaire voisin (.<nom>.partiel.<pid>), puis renommage : un make setup interrompu
# ne laisse jamais un espace à moitié copié, et la relance reprend la copie de zéro. Les dossiers temporaires
# laissés par une copie tuée (processus disparu) sont supprimés à la relance ; ils ne contiennent jamais le
# travail de l'élève. Un espace existant n'est jamais modifié : s'il lui manque des éléments de starter/
# (copie interrompue par une version antérieure du cadre, ou suppression par l'élève), le message le dit et
# donne la marche à suivre. À la création, si l'espace contient sonde-vitesse.sh, elle est lancée (voir la fin).
# Codes : 0 espace créé ou déjà présent ; 1 copie impossible.
set -u
[ $# -eq 3 ] || { echo "usage : sh espace.sh STARTER WORKSPACE LAB_ID" >&2; exit 64; }
starter=$1 espace=$2 lab=$3
case $starter in /*) ;; *) starter=$(pwd)/$starter ;; esac
case $espace in /*) ;; *) espace=$(pwd)/$espace ;; esac
parent=$(dirname "$espace")
nom=$(basename "$espace")

[ -d "$starter" ] || { echo "starter/ introuvable : $starter ; rien n'est créé." >&2; exit 1; }

# Restes d'une copie tuée sans pouvoir nettoyer (kill -9, coupure) : seulement si leur processus a disparu.
for reste in "$parent/.$nom.partiel."*; do
    [ -d "$reste" ] && [ ! -L "$reste" ] || continue
    pid=${reste##*.}
    case $pid in ''|*[!0-9]*) continue ;; esac
    kill -0 "$pid" 2>/dev/null || rm -rf "$reste"
done

if [ -L "$espace" ] || { [ -e "$espace" ] && [ ! -d "$espace" ]; }; then
    echo "$espace existe mais n'est pas un dossier : renommez-le ou supprimez-le, puis relancez make setup." >&2
    exit 1
fi

if [ -d "$espace" ]; then
    # Éléments de starter/ absents de l'espace ; un dossier manquant est cité seul, sans son contenu.
    manquants=$(cd "$starter" && find . -print | LC_ALL=C sort | {
        haut=
        while IFS= read -r p; do
            [ "$p" = . ] && continue
            if [ -n "$haut" ]; then
                case $p in ("$haut"/*) continue ;; esac   # ( en tête : bash 3.2 (sh de macOS) dans $( )
            fi
            if [ ! -e "$espace/$p" ] && [ ! -L "$espace/$p" ]; then
                haut=$p
                printf '%s\n' "${p#./}"
            fi
        done
    })
    if [ -z "$manquants" ]; then
        echo "Espace de travail déjà présent, rien n'est modifié : $espace"
        exit 0
    fi
    n=$(printf '%s\n' "$manquants" | wc -l | tr -d ' ')
    premier=$(printf '%s\n' "$manquants" | head -n 1)
    liste=$(printf '%s\n' "$manquants" | head -n 5 | tr '\n' ',' | sed 's/,$//; s/,/, /g')
    [ "$n" -gt 5 ] && liste="$liste…"
    echo "Espace de travail incomplet : $n élément(s) de starter/ manquent dans $espace ($liste)."
    echo "Rien n'est modifié : votre travail reste tel quel."
    echo "Si un make setup précédent a été interrompu, recréez l'espace avec make clean puis make setup (make clean efface tout l'espace, votre travail compris)."
    echo "Pour garder votre travail, copiez seulement ce qui manque, par exemple : cp -Rp \"$starter/$premier\" \"$espace/$premier\""
    echo "Si vous avez supprimé ces éléments vous-même, ce message ne vous concerne pas."
    exit 0
fi

mkdir -p "$parent" || exit 1
tmp="$parent/.$nom.partiel.$$"
rm -rf "$tmp"
trap 'rm -rf "$tmp"' EXIT
trap 'exit 129' HUP
trap 'exit 130' INT
trap 'exit 143' TERM
if ! { mkdir "$tmp" && cp -Rp "$starter/." "$tmp/"; }; then
    echo "Copie de starter/ impossible ; aucun espace n'est créé, relancez make setup une fois la cause corrigée." >&2
    exit 1
fi
if [ -e "$espace" ] || [ -L "$espace" ]; then
    # Créé entre-temps par un autre make setup : on garde le sien.
    echo "Espace de travail déjà présent, rien n'est modifié : $espace"
    exit 0
fi
# Même dossier parent, donc même système de fichiers : mv est un renommage (rename), atomique.
mv "$tmp" "$espace" || exit 1
if [ -d "$espace/.$nom.partiel.$$" ]; then
    # Course perdue de justesse (espace créé entre le test et mv) : mv a rangé la copie dedans ; on la retire.
    rm -rf "$espace/.$nom.partiel.$$"
    echo "Espace de travail déjà présent, rien n'est modifié : $espace"
    exit 0
fi
echo "Espace de travail créé : $espace"
echo "Travaillez dans ce dossier (cd $nom), puis vérifiez avec sagnac check $lab"
# Sonde de vitesse du lab (story 2-4a, B1-M5) : un lab dont la vérification dépend de la vitesse du poste livre
# starter/sonde-vitesse.sh, lancé ici une fois, à la création de l'espace. Elle prévient, elle n'échoue jamais :
# make setup rend 0 quel que soit son résultat. SAGNAC_SONDE=0 la saute (harnais de l'oracle, essais).
if [ -f "$espace/sonde-vitesse.sh" ] && [ "${SAGNAC_SONDE:-1}" != 0 ]; then
    (cd "$espace" && sh ./sonde-vitesse.sh) || true
fi
