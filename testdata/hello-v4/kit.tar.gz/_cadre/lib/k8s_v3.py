"""Contrat de cluster v3 (ADR-007, CONTRAT.md § 7 quater) : outils des contrôles, code de confiance.

Bibliothèque standard seulement ; tout passe par le kubectl épinglé et le kubeconfig de l'identité contrôle du
cache Sagnac (jamais l'administrateur). Utilisé de deux façons :
  python3 k8s_v3.py appliquer CHEMIN     appelé par sagnac_k8s_appliquer (lib/controle.sh) sur un cluster v3 ;
                                         rend 0, ou 1 avec le code de refus sur la sortie standard
  import k8s_v3                          depuis checks/lib/*.py d'un lab v3 (Kube, configmap, lancer_pod)

Règles de `appliquer` (ADR-007) :
- chaque objet est d'une sorte de SORTES_V3 (ou de SAGNAC_K8S_SORTES, qui ne peut qu'en retirer) ;
- un objet d'espace va dans un espace élève (défaut : le premier) ; tout autre `namespace:` est refusé ;
- un Namespace ne porte que des étiquettes pod-security.kubernetes.io/* d'un espace élève : elles remplacent
  celles de l'espace (rien d'autre ne change) ;
- VAP, liaisons de VAP et RuntimeClass reçoivent sagnac.fr/origine=eleve ; leur nom ne commence pas par
  « sagnac- » (réservé au socle) ; une liaison de VAP vise seulement des espaces élèves (G2, qu'aucune VAP ne
  peut tenir : une VAP ne garde pas les VAP) ;
- C3 (B4) : Application et ApplicationSet d'Argo CD, dans un espace élève comme toute sorte d'espace ;
- essai à blanc côté serveur sous l'identité contrôle (PSA, RBAC, garde-fous et VAP de l'élève), puis
  application réelle ; les RoleBinding qui citent un Role du même lot ne sont jugés qu'à l'application réelle
  (à blanc, le Role n'existe pas encore : voir a_blanc).
- C1 à C5 (B5) : cronjob.batch dans les espaces élèves ; ValidatingPolicy Kyverno marquée d'origine élève, nom
  hors « sagnac- », matchConstraints.namespaceSelector limité aux espaces élèves, resourceRules « Namespaced », CEL
  sans http.*, resource.* (sauf resource.Get d'un ConfigMap d'inventaire), globalContext.*, imagedata.* ; aucun
  objet de l'élève dans l'espace inventaire, écrit par le seul contrôle.
Codes de refus : rejected (manifeste invalide, espace hors des espaces élèves, nom réservé, liaison trop large),
forbidden_kind (sorte hors liste ou refusée par le rôle), pod_security (PSA), admission (VAP, garde-fou).
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path

SORTES_V3 = ("pod service configmap secret persistentvolumeclaim deployment.apps statefulset.apps job.batch "
             "cronjob.batch "
             "networkpolicy.networking.k8s.io role.rbac.authorization.k8s.io "
             "rolebinding.rbac.authorization.k8s.io serviceaccount "
             "validatingadmissionpolicy.admissionregistration.k8s.io "
             "validatingadmissionpolicybinding.admissionregistration.k8s.io runtimeclass.node.k8s.io namespace "
             "validatingpolicy.policies.kyverno.io").split()
KYVERNO_VP = "validatingpolicy.policies.kyverno.io"   # C1 (B5) : politique Kyverno, traitée comme une VAP
# C3 (B4-M5) : applications et ensembles d'applications d'Argo CD, dans les espaces élèves seulement (sortes
# d'espace : preparer refuse tout autre espace). Sans Argo CD, la sorte n'existe pas et l'essai à blanc refuse
# (rejected). Leur portée réelle (projet, destinations, dépôts) est tenue par la configuration d'Argo CD posée
# par l'administrateur, jamais par l'élève (socle S3 de B4).
SORTES_ARGO_V3 = ("application.argoproj.io", "applicationset.argoproj.io")
SORTES_V3 += SORTES_ARGO_V3
PORTEE_CLUSTER = {"validatingadmissionpolicy.admissionregistration.k8s.io",
                  "validatingadmissionpolicybinding.admissionregistration.k8s.io", "runtimeclass.node.k8s.io",
                  KYVERNO_VP}
# C4 (B5) : espace élève écrit par le seul contrôle, après validation (inventaire des modèles de M5-L1). Les
# manifestes de l'élève n'y vont pas (k8s_v3), ses comptes n'y écrivent pas (G4).
ESPACES_ECRITS_PAR_LE_CONTROLE = ("inventaire",)
# C5 (B5) : le CEL d'une politique Kyverno de l'élève n'appelle ni http.*, ni resource.* (sauf resource.Get d'un
# ConfigMap de l'espace inventaire), ni globalContext.*, ni imagedata.* : le moteur d'admission ne devient pas un
# canal vers les valeurs du contrôle (sagnac-oracle, secrets) ni vers le réseau. CEL n'a ni commentaire ni appel
# par nom calculé : une lecture de toutes les chaînes de spec suffit (une chaîne littérale qui contient
# « http.Get » est refusée aussi, par prudence).
CEL_INTERDIT = re.compile(r"(?<![\w.])(http|resource|globalContext|imagedata)\s*\.\s*[A-Za-z_]+")
CEL_GET_PERMIS = re.compile(
    r"""\bresource\s*\.\s*Get\s*\(\s*(["'])v1\1\s*,\s*(["'])configmaps\2\s*,\s*(["'])inventaire\3\s*,""")
ORIGINE = "sagnac.fr/origine"
PSA = "pod-security.kubernetes.io/"
ORACLE = "sagnac-oracle"
CONFIGMAP_MAX = 1024 * 1024
DERNIERE_ERREUR = [""]   # dernier refus détaillé (sortie d'erreur du serveur ou règle), pour le diagnostic


class Refus(Exception):
    def __init__(self, code: str, detail: str = ""):
        super().__init__(f"{code}: {detail}")
        self.code = code


class Kube:
    """kubectl de l'identité contrôle du cluster du lab (SAGNAC_CLUSTER)."""

    def __init__(self, cluster: str | None = None):
        cluster = cluster or os.environ.get("SAGNAC_CLUSTER", "")
        if not cluster:
            raise SystemExit("SAGNAC_CLUSTER absent : le lab ne déclare pas de cluster")
        d = Path(os.environ.get("HOME", "/nonexistent")) / ".cache" / "sagnac" / "clusters" / cluster
        self.base = [str(d / "kubectl"), "--kubeconfig", str(d / "kubeconfig"), "--request-timeout=20s"]
        self._espaces: list[str] | None = None

    def run(self, *args, entree: str | None = None, timeout: float = 60) -> subprocess.CompletedProcess:
        return subprocess.run([*self.base, *map(str, args)], input=entree, capture_output=True, text=True,
                              timeout=timeout)

    def json(self, *args, timeout: float = 60):
        r = self.run(*args, "-o", "json", timeout=timeout)
        if r.returncode != 0:
            return None
        return json.loads(r.stdout or "null")

    def espaces(self) -> list[str]:
        """Espaces élèves (étiquette sagnac.fr/espace=eleve), par ordre alphabétique."""
        if self._espaces is None:
            r = self.run("get", "namespaces", "-l", "sagnac.fr/espace=eleve", "-o",
                         "jsonpath={range .items[*]}{.metadata.name}{\"\\n\"}{end}")
            self._espaces = sorted(r.stdout.split()) if r.returncode == 0 else []
        return self._espaces

    def appliquer_json(self, objets: list, essai: bool = False) -> subprocess.CompletedProcess:
        args = ["apply", "-f", "-"] + (["--dry-run=server"] if essai else [])
        return self.run(*args, entree=json.dumps({"apiVersion": "v1", "kind": "List", "items": objets}))


def objets_json(texte: str) -> list:
    """Objets d'une sortie `kubectl … -o json` : un objet, une List, ou plusieurs objets à la suite (un par
    document YAML)."""
    dec, i, objets = json.JSONDecoder(), 0, []
    while True:
        while i < len(texte) and texte[i].isspace():
            i += 1
        if i >= len(texte):
            return objets
        o, i = dec.raw_decode(texte, i)
        objets += o.get("items", []) if isinstance(o, dict) and o.get("kind") == "List" else [o]


def sorte(o: dict) -> str:
    groupe = o.get("apiVersion", "").rpartition("/")[0]
    return o.get("kind", "").lower() + (f".{groupe}" if groupe else "")


def _refus_serveur(stderr: str) -> str:
    bas = stderr.lower()
    if "violate" in bas and "podsecurity" in bas.replace(" ", ""):
        return "pod_security"
    if "validatingadmissionpolicy" in bas or "denied request" in bas or "denied the request" in bas:
        return "admission"
    if "forbidden" in bas:
        return "forbidden_kind"
    return "rejected"


def _liaison_dans_espaces(o: dict, espaces: list[str]) -> bool:
    sel = (o.get("spec", {}).get("matchResources") or {}).get("namespaceSelector")
    if not isinstance(sel, dict):
        return False
    if (sel.get("matchLabels") or {}).get("sagnac.fr/espace") == "eleve":
        return True
    for e in sel.get("matchExpressions") or []:
        if (e.get("key") == "kubernetes.io/metadata.name" and e.get("operator") == "In"
                and e.get("values") and set(e["values"]) <= set(espaces)):
            return True
    return False


def _chaines(v) -> list[str]:
    if isinstance(v, str):
        return [v]
    if isinstance(v, dict):
        return [c for x in v.values() for c in _chaines(x)]
    if isinstance(v, list):
        return [c for x in v for c in _chaines(x)]
    return []


def cel_refuse(spec: dict) -> str:
    """C5 : premier appel interdit trouvé dans le CEL d'une politique Kyverno de l'élève, ou ""."""
    for texte in _chaines(spec):
        for m in CEL_INTERDIT.finditer(texte):
            if not CEL_GET_PERMIS.match(texte, m.start()):
                return m.group(0)
    return ""


def verifier_politique_kyverno(o: dict, espaces: list[str]) -> None:
    """C1 et C5 : une ValidatingPolicy de l'élève ne vise que des objets d'espace des espaces élèves (sélecteur
    d'espaces comme une liaison de VAP, règles « Namespaced » : un objet à portée cluster échappe au sélecteur
    d'espaces) et son CEL n'appelle aucun service. Lève Refus."""
    spec = o.get("spec") or {}
    contraintes = spec.get("matchConstraints") or {}
    if not _liaison_dans_espaces({"spec": {"matchResources": contraintes}}, espaces):
        raise Refus("rejected", "politique Kyverno hors des espaces élèves (matchConstraints.namespaceSelector)")
    regles = contraintes.get("resourceRules") or []
    if not regles:
        raise Refus("rejected", "politique Kyverno sans resourceRules")
    for r in regles:
        if r.setdefault("scope", "Namespaced") != "Namespaced":
            raise Refus("rejected", "politique Kyverno : resourceRules[].scope doit valoir Namespaced")
    interdit = cel_refuse(spec)
    if interdit:
        raise Refus("rejected", f"politique Kyverno : appel {interdit} interdit dans le CEL (C5)")


def preparer(kube: Kube, objets: list, sortes: list[str]) -> tuple[list, dict]:
    """Objets à appliquer, et étiquettes Pod Security par espace élève. Lève Refus."""
    espaces = kube.espaces()
    if not espaces:
        raise Refus("rejected", "aucun espace élève sur ce cluster")
    defaut = os.environ.get("SAGNAC_NS") or espaces[0]
    if defaut not in espaces:
        raise Refus("rejected", f"espace par défaut {defaut} hors des espaces élèves")
    a_appliquer, psa = [], {}
    for o in objets:
        s = sorte(o)
        meta = o.setdefault("metadata", {})
        if s not in sortes:
            raise Refus("forbidden_kind", s)
        if s == "namespace":
            nom = meta.get("name", "")
            etiquettes = meta.get("labels") or {}
            if nom not in espaces or any(v for k, v in o.items() if k not in ("apiVersion", "kind", "metadata")):
                raise Refus("rejected", f"espace {nom}")
            if set(meta) - {"name", "labels", "creationTimestamp"} or any(not k.startswith(PSA) for k in etiquettes):
                raise Refus("rejected", f"espace {nom} : seules les étiquettes {PSA}* changent")
            psa[nom] = etiquettes
            continue
        if s in PORTEE_CLUSTER:
            if meta.get("namespace"):
                raise Refus("rejected", f"{s} sans espace")
            if meta.get("name", "").startswith("sagnac-"):
                raise Refus("rejected", f"nom réservé {meta.get('name')}")
            meta.setdefault("labels", {})[ORIGINE] = "eleve"
            if s.startswith("validatingadmissionpolicybinding") and not _liaison_dans_espaces(o, espaces):
                raise Refus("rejected", "liaison de VAP hors des espaces élèves")
            if s == KYVERNO_VP:
                verifier_politique_kyverno(o, espaces)
        else:
            ns = meta.setdefault("namespace", defaut)
            if ns not in espaces:
                raise Refus("rejected", f"espace {ns} hors des espaces élèves")
            if ns in ESPACES_ECRITS_PAR_LE_CONTROLE:
                raise Refus("rejected", f"espace {ns} : écrit par le seul contrôle (C4)")
            if "sagnac.fr/socle" in (meta.get("labels") or {}):
                raise Refus("rejected", "étiquette du socle")
        a_appliquer.append(o)
    return a_appliquer, psa


def a_blanc(objets: list) -> list:
    """Objets de l'essai à blanc : sans les RoleBinding qui citent un Role du même lot. À blanc, ce Role n'existe
    pas encore, et l'identité contrôle (sans `bind`) ne peut lier qu'un rôle existant dont elle détient les droits :
    l'API répondrait NotFound. Le Role lui-même passe l'essai (contrôle d'escalade), la liaison est jugée par
    l'application réelle, qui suit l'ordre du fichier."""
    roles = {(o["metadata"].get("namespace"), o["metadata"].get("name")) for o in objets
             if sorte(o) == "role.rbac.authorization.k8s.io"}

    def cite_un_role_du_lot(o: dict) -> bool:
        ref = o.get("roleRef") or {}
        return (sorte(o) == "rolebinding.rbac.authorization.k8s.io" and ref.get("kind") == "Role"
                and (o["metadata"].get("namespace"), ref.get("name")) in roles)

    return [o for o in objets if not cite_un_role_du_lot(o)]


def poser_psa(kube: Kube, psa: dict, essai: bool) -> str:
    for nom, voulues in psa.items():
        ns = kube.json("get", "namespace", nom) or {}
        actuelles = {k for k in (ns.get("metadata", {}).get("labels") or {}) if k.startswith(PSA)}
        args = [f"{k}={v}" for k, v in sorted(voulues.items())] + [f"{k}-" for k in sorted(actuelles - set(voulues))]
        if not args:
            continue
        r = kube.run("label", "namespace", nom, "--overwrite", *args, *(["--dry-run=server"] if essai else []))
        if r.returncode != 0:
            DERNIERE_ERREUR[0] = r.stderr[-600:]
            return _refus_serveur(r.stderr)
    return ""


def appliquer(chemin: str, kube: Kube | None = None) -> str:
    """Applique les manifestes de l'élève (fichier ou dossier). Rend "" ou le code de refus."""
    kube = kube or Kube()
    r = kube.run("create", "--dry-run=client", "--validate=false", "-o", "json", "-R", "-f", chemin)
    if r.returncode != 0 or not r.stdout.strip():
        DERNIERE_ERREUR[0] = r.stderr[-600:]
        return "rejected"
    try:
        objets = objets_json(r.stdout)
    except ValueError as e:
        DERNIERE_ERREUR[0] = str(e)
        return "rejected"
    if not objets:
        return "rejected"
    permises = os.environ.get("SAGNAC_K8S_SORTES", "").split() or SORTES_V3
    sortes = [s for s in permises if s in SORTES_V3]
    try:
        objets, psa = preparer(kube, objets, sortes)
    except Refus as e:
        DERNIERE_ERREUR[0] = str(e)
        return e.code
    for essai in (True, False):   # étiquettes Pod Security d'abord : elles jugent les pods qui suivent
        code = poser_psa(kube, psa, essai)
        if code:
            return code
        lot = a_blanc(objets) if essai else objets
        if lot:
            r = kube.appliquer_json(lot, essai=essai)
            if r.returncode != 0:
                DERNIERE_ERREUR[0] = r.stderr[-600:]
                return _refus_serveur(r.stderr)
            if essai and "violate" in r.stderr and "PodSecurity" in r.stderr:
                return "pod_security"
    return ""


# --- Kyverno (B5, C3) : précondition ADMISSION_CONTROLLER_DOWN -------------------------------------

KYVERNO_NS = "kyverno"
KYVERNO_ADMISSION = "kyverno-admission-controller"


def admission_prete(kube: Kube) -> tuple[bool, str]:
    """Le contrôleur d'admission de Kyverno tourne ET ses webhooks sont posés (E-B5-1 : arrêté, il retire ses
    webhooks et l'admission s'ouvre, bien qu'ils soient en Fail). Tout contrôle d'admission l'appelle d'abord et
    rend ADMISSION_CONTROLLER_DOWN (précondition, origine platform, code 2) si (False, raison)."""
    d = kube.json("-n", KYVERNO_NS, "get", "deployment", KYVERNO_ADMISSION)
    if not d:
        return False, "Kyverno absent (relancez make setup)"
    if (d.get("status") or {}).get("availableReplicas", 0) < 1:
        return False, "contrôleur d'admission de Kyverno arrêté"
    w = kube.json("get", "validatingwebhookconfigurations") or {}
    for cfg in w.get("items", []):
        for h in cfg.get("webhooks") or []:
            svc = (h.get("clientConfig") or {}).get("service") or {}
            if svc.get("namespace") == KYVERNO_NS:
                return True, ""
    return False, "webhooks de Kyverno absents : l'admission est ouverte"


# --- aides des contrôles des labs v3 --------------------------------------------------------------

def configmap(ns: str, nom: str, fichiers: dict[str, str], etiquettes: dict | None = None) -> dict:
    """ConfigMap des fichiers de workspace/ (1 Mio au plus, ADR-007), montée en lecture seule par lancer_pod."""
    taille = sum(len(v.encode("utf-8")) for v in fichiers.values())
    if taille > CONFIGMAP_MAX:
        raise Refus("rejected", f"ConfigMap {nom} : {taille} octets (1 Mio au plus)")
    return {"apiVersion": "v1", "kind": "ConfigMap",
            "metadata": {"name": nom, "namespace": ns, "labels": {"sagnac.fr/passage": "1", **(etiquettes or {})}},
            "data": fichiers}


def attendre_pod(kube: Kube, ns: str, nom: str, delai_s: float) -> dict:
    """Attend la fin d'un pod (Succeeded, Failed) ou le délai. Rend {phase, code, raison, journal, secondes}."""
    debut = time.monotonic()
    pod = {}
    while time.monotonic() - debut < delai_s:
        pod = kube.json("-n", ns, "get", "pod", nom) or {}
        if pod.get("status", {}).get("phase") in ("Succeeded", "Failed"):
            break
        time.sleep(0.4)
    statut = pod.get("status", {})
    etats = statut.get("containerStatuses") or [{}]
    fin = (etats[0].get("state") or {}).get("terminated") or {}
    journal = kube.run("-n", ns, "logs", nom, "--tail=200").stdout if statut.get("phase") else ""
    return {"phase": statut.get("phase", ""), "code": fin.get("exitCode"), "raison": fin.get("reason", ""),
            "journal": journal, "secondes": round(time.monotonic() - debut, 2)}


if __name__ == "__main__":
    if len(sys.argv) == 3 and sys.argv[1] == "appliquer":
        code = appliquer(sys.argv[2])
        if code:
            print(code)
            print(DERNIERE_ERREUR[0], file=sys.stderr)
            sys.exit(1)
        sys.exit(0)
    print("usage : k8s_v3.py appliquer CHEMIN", file=sys.stderr)
    sys.exit(64)
